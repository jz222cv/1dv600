package run;

import controller.Play;

public class Program {
    public static void main(String[] args) {
        Play play = new Play();
        play.start();
    }
}
