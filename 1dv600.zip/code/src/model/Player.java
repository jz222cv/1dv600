package model;

public class Player {
	
    private String name;

    public Player(String playerName) {
        name = playerName;
    }
    
    public String getName() {
    	return name;
    }
    
}

